import { PHONE_HREF, SITE } from '../config/site';
import { googleReviews, hero } from '../data/placeholderContent';
import { getImage } from '../data/images';
import { Img } from './ui/Img';
import { Container } from './ui/Layout';
import { CtaButton } from './ui/CtaButton';
import { PhoneCall, Star } from './ui/icons';

/** Google "G" logo (four-colour). */
function GoogleG({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 18 18" aria-hidden="true" focusable="false" className={className}>
      <path fill="#4285F4" d="M17.64 9.2045c0-.6381-.0573-1.2518-.1636-1.8409H9v3.4814h4.8436c-.2086 1.125-.8427 2.0782-1.7959 2.7164v2.2581h2.9087c1.7018-1.5668 2.6836-3.874 2.6836-6.615z" />
      <path fill="#34A853" d="M9 18c2.43 0 4.4673-.8059 5.9564-2.1805l-2.9087-2.2581c-.8059.54-1.8368.859-3.0477.859-2.344 0-4.3282-1.5831-5.0359-3.7104H.9573v2.3318C2.4382 15.9832 5.4818 18 9 18z" />
      <path fill="#FBBC05" d="M3.9641 10.71c-.18-.54-.2823-1.1168-.2823-1.71s.1023-1.17.2823-1.71V4.9582H.9573A8.9965 8.9965 0 0 0 0 9c0 1.4523.3477 2.8268.9573 4.0418L3.9641 10.71z" />
      <path fill="#EA4335" d="M9 3.5795c1.3214 0 2.5077.4541 3.4405 1.346l2.5813-2.5814C13.4636.8918 11.4264 0 9 0 5.4818 0 2.4382 2.0168.9573 4.9582L3.9641 7.29C4.6718 5.1627 6.6559 3.5795 9 3.5795z" />
    </svg>
  );
}

/**
 * Google reviews banner: white panel with the Google logo, rating, gold stars and review count.
 * Gold stars and the Google colours are a deliberate exception to the navy/amber palette so it reads as Google.
 */
function GoogleRating() {
  const { rating, count, note } = googleReviews;
  return (
    <div
      role="img"
      aria-label={`Google reviews: rated ${rating} out of 5 from ${count} reviews. ${note}`}
      className="mt-8 inline-flex max-w-full items-center gap-4 rounded-md bg-white px-4 py-3 text-navy shadow-lg sm:gap-5 sm:px-5"
    >
      <GoogleG className="size-10 shrink-0 sm:size-12" />
      <div aria-hidden="true" className="min-w-0">
        <p className="font-display text-lg font-bold leading-tight sm:text-xl">Google reviews</p>
        <p className="mt-0.5 flex flex-wrap items-center gap-x-2.5 gap-y-0.5">
          <span className="font-display text-xl font-extrabold sm:text-2xl">{rating}</span>
          <span className="flex gap-0.5 text-[#FBBC04]">
            {[0, 1, 2, 3, 4].map((n) => (
              <Star key={n} className="size-5 sm:size-6" fill="currentColor" strokeWidth={0} />
            ))}
          </span>
          <span className="text-base text-slate sm:text-lg">{count} reviews</span>
        </p>
        <p className="mt-1 text-sm text-slate sm:text-base">{note}</p>
      </div>
    </div>
  );
}

/**
 * Hero (navy). Left: headline, CTA (opens the quote pop-up) and the Google rating.
 * From large screens the lightly blurred key photo fills the whole hero as a background, fading to navy behind the text. On phones the photo sits above the text and fades into the navy.
 */
export function Hero() {
  const photo = getImage('hero-keys');
  return (
    <section aria-labelledby="hero-heading" className="relative overflow-hidden bg-navy text-white">
      {/* Photo: full-width banner on phones, full hero background on large screens. */}
      <div className="relative h-64 overflow-hidden sm:h-80 lg:absolute lg:inset-0 lg:h-auto">
        {/* Slightly blurred (and scaled up so the blur does not show soft edges) so the text stays the focus. */}
        <Img image={photo} priority sizes="100vw" className="scale-105 blur-[3px]" />
        <div
          aria-hidden="true"
          className="absolute inset-0 bg-gradient-to-t from-navy via-navy/20 to-transparent lg:bg-gradient-to-r lg:from-navy lg:from-30% lg:via-navy/65 lg:via-50% lg:to-navy/5"
        />
      </div>

      <Container className="relative z-20 -mt-10 pb-10 lg:mt-0 lg:py-24 xl:py-28">
        <div className="max-w-xl lg:max-w-[34rem] xl:max-w-[38rem]">
          <p className="text-base font-semibold text-white/80">{hero.eyebrow}</p>
          <h1
            id="hero-heading"
            className="mt-3 text-balance text-[2.5rem] font-extrabold leading-[1.02] sm:text-5xl lg:text-[3.4rem]"
          >
            {hero.headline}
          </h1>
          <p className="mt-5 max-w-lg text-lg text-white/85">{hero.subhead}</p>

          <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-5">
            <CtaButton size="lg" className="w-full sm:w-auto" />
          </div>

          {/* Call link sits directly under the button. */}
          <a
            href={PHONE_HREF}
            className="mt-3 inline-flex min-h-12 items-center gap-2 rounded-lg text-lg font-semibold text-white"
          >
            <PhoneCall className="size-5 text-white/80" aria-hidden="true" />
            <span>
              <span className="font-normal text-white/80">or call </span>
              {SITE.phone}
            </span>
          </a>

          <GoogleRating />
        </div>
      </Container>
    </section>
  );
}
