import { WHATSAPP_CHAT_HREF } from '../config/site';
import { WhatsAppIcon } from './ui/WhatsAppIcon';

/**
 * Fixed WhatsApp button, bottom right, with a "Contact us" tag beside it. Laptop and tablet only (768px and up):
 * on phones the sticky bottom bar already has a WhatsApp button, so this stays hidden there.
 * The brand-green circle with a white symbol is a deliberate exception to the navy/amber palette.
 */
export function FloatingWhatsApp() {
  return (
    <a
      href={WHATSAPP_CHAT_HREF}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Contact us on WhatsApp (opens in a new tab)"
      className="group fixed bottom-6 right-6 z-40 hidden items-center gap-3 md:flex"
    >
      {/* Tag with a small pointer towards the button */}
      <span
        aria-hidden="true"
        className="relative rounded-lg bg-white px-4 py-2.5 text-lg font-medium text-navy shadow-lg ring-1 ring-navy/10 after:absolute after:-right-1 after:top-1/2 after:size-3 after:-translate-y-1/2 after:rotate-45 after:rounded-[2px] after:bg-white after:content-['']"
      >
        Contact us
      </span>
      <span
        aria-hidden="true"
        className="inline-flex size-16 items-center justify-center rounded-full bg-gradient-to-b from-[#5af475] to-[#25d04a] text-white shadow-xl ring-1 ring-black/5 transition group-hover:scale-105 group-active:scale-95"
      >
        <WhatsAppIcon className="size-9" />
      </span>
    </a>
  );
}
