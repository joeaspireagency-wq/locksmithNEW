import { useRef } from 'react';
import { stats } from '../../data/placeholderContent';
import type { Stat } from '../../data/placeholderContent';
import { useCountUp } from '../../hooks/useCountUp';
import { useInView } from '../../hooks/useInView';

function formatStat(stat: Stat, value: number): string {
  const formatted = value.toLocaleString('en-GB', {
    minimumFractionDigits: stat.decimals,
    maximumFractionDigits: stat.decimals,
  });
  return `${stat.prefix}${formatted}${stat.suffix}`;
}

function StatItem({ stat, active }: { stat: Stat; active: boolean }) {
  const value = useCountUp(stat.value, active);

  return (
    <div className="border-l-2 border-navy pl-4 sm:pl-5">
      <p className="font-display text-4xl font-extrabold text-navy sm:text-5xl lg:text-6xl">
        {/* Screen readers get the final figure at once; sighted visitors see the count-up. */}
        <span className="sr-only">{formatStat(stat, stat.value)}</span>
        <span aria-hidden="true">{formatStat(stat, value)}</span>
      </p>
      <p className="mt-1.5 text-base text-slate">{stat.label}</p>
    </div>
  );
}

/** Four headline numbers. They count up on scroll, except under prefers-reduced-motion. */
export function ResultsBar() {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, 0.3);

  return (
    <div
      ref={ref}
      className="grid grid-cols-2 gap-x-4 gap-y-8 lg:grid-cols-4 lg:gap-x-8"
    >
      {stats.map((stat) => (
        <StatItem key={stat.id} stat={stat} active={inView} />
      ))}
    </div>
  );
}
