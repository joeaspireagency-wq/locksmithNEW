import type { Review } from '../../data/placeholderContent';
import { Star } from '../ui/icons';

/**
 * One review. Stars are navy (never amber, which is reserved for the CTA).
 * Driven entirely by the Review type, so real reviews can replace the data
 * in placeholderContent.ts without any change here.
 */
export function ReviewCard({ review }: { review: Review }) {
  return (
    <figure className="flex h-full w-full flex-col rounded-xl border border-slate/25 bg-white p-6 shadow-sm md:grid md:grid-cols-[15rem_minmax(0,1fr)] md:grid-rows-[auto_1fr] md:gap-x-12 md:p-10">
      <div className="flex items-center justify-between gap-3 md:col-start-1 md:row-start-1">
        <div role="img" aria-label={`${review.rating} out of 5 stars`} className="flex gap-0.5">
          {Array.from({ length: 5 }, (_, index) => (
            <Star
              key={index}
              aria-hidden="true"
              className={index < review.rating ? 'size-5 fill-navy text-navy' : 'size-5 text-slate/40'}
            />
          ))}
        </div>
      </div>

      <blockquote className="font-display mt-5 flex-1 text-lg font-semibold leading-snug text-navy md:col-start-2 md:row-span-2 md:row-start-1 md:mt-0 md:flex md:items-center md:border-l md:border-slate/20 md:pl-12 md:text-3xl">
        <p>&ldquo;{review.quote}&rdquo;</p>
      </blockquote>

      <figcaption className="mt-5 border-t border-slate/20 pt-4 md:col-start-1 md:row-start-2 md:mt-6 md:self-end md:border-t-0 md:pt-0">
        <p className="text-base font-bold text-navy">
          {review.name}, <span className="font-semibold text-slate">{review.area}</span>
        </p>
        <p className="text-sm text-slate">{review.service}</p>
      </figcaption>
    </figure>
  );
}
