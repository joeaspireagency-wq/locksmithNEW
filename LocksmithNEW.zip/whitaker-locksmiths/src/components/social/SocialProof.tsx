import { beforeAfter, socialProof } from '../../data/placeholderContent';
import { getImage } from '../../data/images';
import { Section, SectionHeading } from '../ui/Layout';
import { Reveal } from '../ui/Reveal';
import { BeforeAfterSlider } from './BeforeAfterSlider';
import { ResultsBar } from './ResultsBar';
import { ReviewSlider } from './ReviewSlider';

function SubHeading({ children }: { children: string }) {
  return <h3 className="mb-6 text-2xl font-extrabold tracking-tight text-navy md:text-3xl">{children}</h3>;
}

/**
 * Social proof: results bar, before/after slider and a one-at-a-time review slider.
 * All figures and quotes are demo content from src/data/placeholderContent.ts.
 */
export function SocialProof() {
  return (
    <Section id="reviews" labelledBy="proof-heading" tone="white">
      <SectionHeading id="proof-heading" tone="white" title={socialProof.heading} compact />

      <ResultsBar />

      <div className="mt-14">
        <SubHeading>{socialProof.beforeAfterHeading}</SubHeading>
        <ul className={beforeAfter.length > 1 ? 'grid gap-6 md:grid-cols-3' : ''}>
          {beforeAfter.map((item, index) => (
            <li key={item.id} className="flex">
              <Reveal delay={index * 90} className="flex w-full">
                <figure className={beforeAfter.length > 1 ? 'w-full' : 'grid w-full items-center gap-5 md:grid-cols-[minmax(0,1fr)_24rem] md:gap-14 md:rounded-xl md:bg-offwhite md:p-10 lg:p-12'}>
                  <div className={beforeAfter.length > 1 ? '' : 'w-full md:order-2 md:max-w-sm'}>
                      <BeforeAfterSlider
                        before={getImage(item.before)}
                        after={getImage(item.after)}
                        label={item.ariaLabel}
                        showLabels={!item.labelsInImages}
                        squareOnMobile
                        desktopAspectClass="md:aspect-[4/5]"
                      />
                    </div>
                  <figcaption className={beforeAfter.length > 1 ? 'mt-4' : 'md:order-1'}>
                    <span className="inline-flex items-center gap-1.5 rounded-md bg-offwhite px-2.5 py-1 text-sm font-bold text-slate md:bg-white">
                      Job type
                      <span aria-hidden="true">&middot;</span>
                      <span className="text-navy">{item.jobType}</span>
                    </span>
                    <p className={beforeAfter.length > 1 ? 'mt-2 text-base text-navy' : 'font-display mt-3 text-xl font-semibold leading-snug text-navy md:mt-5 md:text-4xl'}>{item.caption}</p>
                  </figcaption>
                </figure>
              </Reveal>
            </li>
          ))}
        </ul>
      </div>

      <div className="mt-14">
        <SubHeading>{socialProof.reviewsHeading}</SubHeading>
        <Reveal>
          <ReviewSlider />
        </Reveal>
      </div>
    </Section>
  );
}
