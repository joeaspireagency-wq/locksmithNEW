import { trustItems } from '../data/placeholderContent';
import { Container } from './ui/Layout';
import { ICONS } from './ui/icons';

/** Four reassurance points directly under the hero: ruled columns, 2x2 on phones, one row from large screens. */
export function TrustStrip() {
  return (
    <section aria-label="Why customers trust us" className="border-b border-navy/10 bg-white">
      <Container>
        <ul className="grid grid-cols-2 lg:grid-cols-4">
          {trustItems.map((item, index) => {
            const Icon = ICONS[item.icon];
            return (
              <li
                key={item.id}
                className={
                  'border-navy/10 py-6 pr-4 sm:py-7 lg:border-l lg:px-6 lg:first:border-l-0 lg:first:pl-0 ' +
                  (index % 2 === 1 ? 'border-l pl-4 lg:pl-6' : '') +
                  (index > 1 ? ' border-t lg:border-t-0' : '')
                }
              >
                <span className="flex items-center gap-2.5">
                  <Icon className="size-5 shrink-0 text-navy" aria-hidden="true" />
                  <span className="font-display text-base font-bold text-navy sm:text-lg">{item.label}</span>
                </span>
                <span className="mt-1 block text-base text-slate">{item.line}</span>
              </li>
            );
          })}
        </ul>
      </Container>
    </section>
  );
}
