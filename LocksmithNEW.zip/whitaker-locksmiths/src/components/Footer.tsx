import { PHONE_HREF, SITE } from '../config/site';
import { footerContent } from '../data/placeholderContent';
import { Logo } from './Logo';
import { Container } from './ui/Layout';
import { Mail, PhoneCall } from './ui/icons';

/**
 * Footer (navy): two columns, then the small print. No CTA here (the final banner above
 * already has one), and no social icons, blog links or extra navigation.
 */
export function Footer() {
  return (
    <footer className="bg-navy text-white">
      <Container>
        {/* Middle row */}
        <div className="grid gap-10 border-t border-white/15 py-12 md:grid-cols-2 md:gap-8">
          <div>
            <Logo tone="dark" />
            <p className="mt-4 max-w-xs text-base text-white/80">{footerContent.brandLine}</p>
            <p className="mt-3 max-w-xs text-base font-semibold text-white">{footerContent.microTagline}</p>
          </div>

          <div>
            <h3 className="text-sm font-bold text-white/70">Contact</h3>
            <ul className="mt-4 space-y-1 text-base">
              <li>
                <a href={PHONE_HREF} className="inline-flex min-h-12 items-center gap-3 rounded-lg font-semibold text-white">
                  <PhoneCall className="size-5 text-white/70" aria-hidden="true" />
                  {SITE.phone}
                </a>
              </li>
              <li>
                <a href={`mailto:${SITE.email}`} className="inline-flex min-h-12 items-center gap-3 break-all rounded-lg text-white">
                  <Mail className="size-5 shrink-0 text-white/70" aria-hidden="true" />
                  {SITE.email}
                </a>
              </li>
            </ul>
            <p className="mt-3 text-base text-white/80">{SITE.hours.emergency}</p>
            <p className="text-base text-white/80">{SITE.hours.bookings}</p>
          </div>

        </div>

        {/* Bottom row. Privacy and Terms are plain text placeholders: link them to real pages at launch. */}
        <div className="flex flex-col gap-3 border-t border-white/15 py-6 text-sm text-white/70 md:flex-row md:items-center md:justify-between">
          <p className="flex flex-wrap gap-x-5 gap-y-1">
            <span>Privacy Policy</span>
            <span>Terms</span>
            <span>{SITE.companyNumber}</span>
            <span>{SITE.icoNumber}</span>
          </p>
          <p>
            &copy; {SITE.copyrightYear} {SITE.businessName}
          </p>
        </div>
      </Container>
    </footer>
  );
}
