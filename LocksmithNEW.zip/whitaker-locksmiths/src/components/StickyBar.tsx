import { PHONE_HREF, SITE, WHATSAPP_CHAT_HREF } from '../config/site';
import { CtaButton } from './ui/CtaButton';
import { Phone } from './ui/icons';
import { WhatsAppIcon } from './ui/WhatsAppIcon';

/**
 * Sticky bottom bar (z-40), phones only (below 768px). The CTA takes most of the width; a phone icon and a WhatsApp icon sit to its right.
 * App.tsx adds matching bottom padding so the bar never covers content or the footer.
 */
export function StickyBar() {
  return (
    <div
      role="region"
      aria-label="Quick actions"
      className="fixed inset-x-0 bottom-0 z-40 border-t border-slate/25 bg-white shadow-[0_-4px_16px_rgba(20,40,63,0.12)] md:hidden"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      <div className="mx-auto grid max-w-xl grid-cols-[minmax(0,1fr)_auto_auto] gap-2 px-3 py-2.5">
        <CtaButton size="compact" block className="text-[15px]! min-[360px]:text-base!" />
        <a
          href={PHONE_HREF}
          aria-label={`Call now on ${SITE.phone}`}
          className="inline-flex size-12 items-center justify-center rounded-lg border-2 border-navy bg-white text-navy transition active:scale-[0.98]"
        >
          <Phone className="size-5" aria-hidden="true" />
        </a>
        <a
          href={WHATSAPP_CHAT_HREF}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Chat on WhatsApp (opens in a new tab)"
          className="inline-flex size-12 items-center justify-center rounded-lg bg-gradient-to-b from-[#5af475] to-[#25d04a] text-white shadow-sm transition active:scale-[0.98]"
        >
          {/* Brand green box with a white symbol, like the WhatsApp app icon: the one deliberate exception to the navy/amber palette. */}
          <WhatsAppIcon className="size-7" />
        </a>
      </div>
    </div>
  );
}
