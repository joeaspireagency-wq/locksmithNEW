import { servicesSection, services } from '../data/placeholderContent';
import { Section, SectionHeading } from './ui/Layout';
import { Reveal } from './ui/Reveal';
import { Check, ICONS } from './ui/icons';
import { Pricing } from './Pricing';

/**
 * Services price board (one ruled row per service) followed by the
 * "What you'll pay" pricing block.
 */
export function Services() {
  return (
    <Section id="services" labelledBy="services-heading" tone="white">
      <SectionHeading
        id="services-heading"
        tone="white"
        title={servicesSection.heading}
        intro={servicesSection.intro}
      />

      {/* Price board: one ruled row per service, price on the right like a workshop price list. */}
      <ul className="border-t-2 border-navy">
        {services.map((service, index) => {
          const Icon = ICONS[service.icon];
          return (
            <li key={service.id} className="border-b border-navy/15">
              <Reveal delay={(index % 3) * 60}>
                <article className="relative grid gap-x-10 gap-y-4 py-6 transition-colors duration-200 hover:bg-offwhite md:grid-cols-[minmax(0,5fr)_minmax(0,5fr)_8rem] md:items-start md:px-4 md:py-7 lg:px-6">
                  <div className="flex gap-4 pr-28 md:pr-0">
                    <span className="inline-flex size-11 shrink-0 items-center justify-center rounded-lg bg-navy text-white">
                      <Icon className="size-5" aria-hidden="true" />
                    </span>
                    <div>
                      <h3 className="text-balance text-xl font-bold leading-snug text-navy md:text-[1.375rem]">
                        {service.name}
                      </h3>
                      <p className="mt-1.5 text-base text-slate">{service.description}</p>
                    </div>
                  </div>

                  <ul className="space-y-2">
                    {service.included.map((item) => (
                      <li key={item} className="flex items-start gap-2.5 text-base text-navy">
                        <Check className="mt-1 size-4 shrink-0 text-slate" strokeWidth={3} aria-hidden="true" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>

                  <p className="absolute right-0 top-6 text-right leading-none md:static md:top-auto md:pt-0.5">
                    <span className="block text-sm font-semibold text-slate">from</span>
                    <span className="font-display mt-1 block text-4xl font-extrabold text-navy md:text-[2.5rem]">
                      £{service.fromPrice}
                    </span>
                  </p>
                </article>
              </Reveal>
            </li>
          );
        })}
      </ul>

      <Pricing />
    </Section>
  );
}
