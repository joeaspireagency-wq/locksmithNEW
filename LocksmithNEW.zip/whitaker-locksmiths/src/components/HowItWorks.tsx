import { howItWorks } from '../data/placeholderContent';
import { Container, SectionHeading } from './ui/Layout';
import { Reveal } from './ui/Reveal';
import { Clock, ICONS } from './ui/icons';

/**
 * Three steps on a connected timeline. Phones: a compact vertical timeline with
 * the icon on the left. From 768px: three columns joined by a dashed line, icons on top.
 * No card boxes, so the section stays short.
 */
export function HowItWorks() {
  return (
    <section id="how-it-works" aria-labelledby="how-heading" className="bg-offwhite py-10 text-navy md:py-12">
      <Container>
        <SectionHeading id="how-heading" tone="offwhite" title={howItWorks.heading} compact />

        <div className="relative mt-6 md:mt-8">
          <ol className="relative grid gap-0 md:grid-cols-3 md:gap-8 lg:gap-12">
            {howItWorks.steps.map((step, index) => {
              const Icon = ICONS[step.icon];
              return (
                <li key={step.id} className="relative pb-7 last:pb-0 md:pb-0">
                  {/* Phone connector: from this circle down to the next one. */}
                  <span
                    aria-hidden="true"
                    className="absolute bottom-0 left-6 top-12 -translate-x-1/2 border-l-2 border-dashed border-slate/40 last:hidden md:hidden"
                  />
                  {/* Desktop connector: from this circle to the next column. */}
                  {index < howItWorks.steps.length - 1 ? (
                    <span
                      aria-hidden="true"
                      className="absolute -right-8 left-[4.75rem] lg:-right-12 top-7 hidden border-t-2 border-dashed border-slate/40 md:block"
                    />
                  ) : null}
                  <Reveal delay={index * 100} className="flex gap-4 md:block">
                    <span className="relative z-10 block shrink-0 md:w-fit">
                      <span
                        aria-hidden="true"
                        className="flex size-12 items-center justify-center rounded-lg bg-navy text-white shadow-md ring-4 ring-offwhite md:size-14"
                      >
                        <Icon className="size-6 md:size-7" />
                      </span>
                      <span
                        aria-hidden="true"
                        className="font-display absolute -right-2 -top-2 flex size-6 items-center justify-center rounded-md bg-white text-xs font-extrabold text-navy ring-2 ring-navy"
                      >
                        {index + 1}
                      </span>
                    </span>

                    <div className="min-w-0 md:mt-4">
                      <h3 className="text-lg font-bold leading-snug text-navy md:text-xl">
                        <span className="sr-only">Step {index + 1}: </span>
                        {step.title}
                      </h3>
                      <p className="mt-1 text-base text-slate">{step.body}</p>
                      <p className="mt-2.5 inline-flex items-center gap-1.5 rounded-md bg-white px-3 py-1 text-sm font-semibold text-navy ring-1 ring-slate/25">
                        <Clock className="size-4 text-slate" aria-hidden="true" />
                        {step.badge}
                      </p>
                    </div>
                  </Reveal>
                </li>
              );
            })}
          </ol>
        </div>
      </Container>
    </section>
  );
}
