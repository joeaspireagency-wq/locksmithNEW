import type { CSSProperties } from 'react';
import { meetDanny } from '../data/placeholderContent';
import { getImage } from '../data/images';
import { Section } from './ui/Layout';
import { Img } from './ui/Img';
import { Reveal } from './ui/Reveal';
import { Check } from './ui/icons';

/** Founder profile: portrait on one side, first-person note and ruled facts on the other. No CTA here by design. */
export function MeetDanny() {
  const portrait = getImage(meetDanny.portrait);

  return (
    <Section id="meet-danny" labelledBy="danny-heading" tone="offwhite">
      <div className="grid items-center gap-10 md:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)] lg:gap-16">
        <Reveal>
          <figure className="w-full md:max-w-sm">
            <div
              className="-mx-4 aspect-[4/3] overflow-hidden bg-navy sm:-mx-6 md:mx-0 md:aspect-(--portrait-ratio) md:rounded-xl md:shadow-lg md:ring-1 md:ring-navy/10"
              style={{ '--portrait-ratio': `${portrait.width} / ${portrait.height}` } as CSSProperties}
            >
              <Img image={portrait} sizes="(min-width: 768px) 384px, 90vw" />
            </div>
            <figcaption className="mt-3 text-base font-semibold text-slate">{meetDanny.caption}</figcaption>
          </figure>
        </Reveal>

        <Reveal delay={100}>
          <h2 id="danny-heading" className="text-3xl font-extrabold leading-[1.08] text-navy md:text-4xl lg:text-[2.75rem]">
            {meetDanny.heading}
          </h2>
          <blockquote className="font-display mt-5 border-l-4 border-navy pl-5 text-xl font-semibold leading-snug text-navy md:text-2xl">
            <p>{meetDanny.blurb}</p>
          </blockquote>
          <p className="mt-5 text-lg font-bold text-navy">{meetDanny.tagline}</p>
          <ul className="mt-5 border-t-2 border-navy">
            {meetDanny.facts.map((fact) => (
              <li key={fact} className="flex items-start gap-3 border-b border-navy/15 py-3 text-base font-semibold text-navy">
                <Check className="mt-1 size-4 shrink-0 text-slate" strokeWidth={3} aria-hidden="true" />
                {fact}
              </li>
            ))}
          </ul>
        </Reveal>
      </div>
    </Section>
  );
}
