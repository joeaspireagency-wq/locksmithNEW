import { PHONE_HREF, SITE } from '../config/site';
import { finalCta } from '../data/placeholderContent';
import { Container } from './ui/Layout';
import { CtaButton } from './ui/CtaButton';
import { PhoneCall } from './ui/icons';

/** Final CTA banner (navy): headline, one supporting line, the CTA, and the phone number beneath. */
export function FinalCta() {
  return (
    <section aria-labelledby="final-cta-heading" className="bg-navy py-14 text-white md:py-20">
      <Container>
        <h2
          id="final-cta-heading"
          className="max-w-3xl text-balance text-3xl font-extrabold leading-[1.08] md:text-4xl lg:text-5xl"
        >
          {finalCta.headline}
        </h2>
        <p className="mt-4 max-w-2xl text-lg text-white/85">{finalCta.support}</p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-6">
          <CtaButton size="lg" className="w-full sm:w-auto" />
          <a
            href={PHONE_HREF}
            className="inline-flex min-h-12 items-center gap-2.5 rounded-lg text-xl font-bold text-white"
          >
            <PhoneCall className="size-5 text-white/80" aria-hidden="true" />
            <span>
              <span className="font-normal text-white/80">Or call </span>
              {SITE.phone}
            </span>
          </a>
        </div>
      </Container>
    </section>
  );
}
