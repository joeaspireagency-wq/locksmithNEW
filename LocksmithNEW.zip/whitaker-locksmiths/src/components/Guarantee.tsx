import { guarantee } from '../data/placeholderContent';
import { SectionHeading, Container } from './ui/Layout';
import { Reveal } from './ui/Reveal';
import { ICONS } from './ui/icons';

/**
 * Guarantee (navy). Four promises in a compact 2x2 grid (1 column on phones), small print.
 *
 * Client must confirm each promise before launch.
 */
export function Guarantee() {
  return (
    <section id="guarantee" aria-labelledby="guarantee-heading" className="bg-navy py-9 text-white md:py-12">
      <Container>
        <SectionHeading id="guarantee-heading" tone="navy" title={guarantee.heading} compact />

        <ul className="mt-6 grid md:mt-8 md:grid-cols-2 md:gap-x-14">
          {guarantee.cards.map((card, index) => {
            const Icon = ICONS[card.icon];
            return (
              <li key={card.id} className="border-t border-white/25">
                <Reveal delay={(index % 2) * 90}>
                  <article className="flex gap-4 py-5 md:py-6">
                    <Icon className="mt-1 size-7 shrink-0 text-white" aria-hidden="true" />
                    <div>
                      <h3 className="text-lg font-bold leading-snug text-white md:text-xl">{card.title}</h3>
                      <p className="mt-1.5 text-[0.95rem] leading-snug text-white/80 md:text-base">{card.body}</p>
                    </div>
                  </article>
                </Reveal>
              </li>
            );
          })}
        </ul>

        <p className="max-w-3xl border-t border-white/25 pt-4 text-sm text-white/70">{guarantee.smallPrint}</p>
      </Container>
    </section>
  );
}
