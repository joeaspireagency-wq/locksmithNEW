/**
 * Image registry. Every image on the site is looked up by id from here, so real
 * project photos can be swapped in by editing one entry: change `src` (and the
 * width, height and alt text to match), and optionally add `srcSet` and `sizes`.
 *
 * The owner portrait (danny-portrait.jpg) is a real photo supplied for this prototype.
 * The before/after photos below are supplied images stored in /public/images. To use stock or real photos, drop them into /public/images (or
 * use full URLs) and update the entries. Set `focalPoint` (x, y as percentages) so
 * the crop keeps the important part of the picture in view.
 */

export type ImageId =
  | 'danny-portrait'
  | 'hero-keys'
  | 'breakin-before'
  | 'breakin-after';

export interface ImageAsset {
  id: ImageId;
  src: string;
  alt: string;
  width: number;
  height: number;
  /** Percentages (0-100) from the top-left of the image. */
  focalPoint: { x: number; y: number };
  srcSet?: string;
  sizes?: string;
}

export const IMAGES: Record<ImageId, ImageAsset> = {
  'danny-portrait': {
    id: 'danny-portrait',
    src: '/images/danny-portrait.jpg',
    alt: 'Danny Whitaker, owner of Whitaker Locksmiths, standing with his arms folded beside his work van',
    width: 819,
    height: 981,
    focalPoint: { x: 50, y: 25 },
  },
  'hero-keys': {
    id: 'hero-keys',
    src: '/images/hero-keys.jpg',
    alt: 'A hand holding up a house key on a house-shaped keyring in front of a brick house',
    width: 1107,
    height: 898,
    focalPoint: { x: 62, y: 50 },
  },
  'breakin-before': {
    id: 'breakin-before',
    src: '/images/breakin-before.jpg',
    alt: 'Before: a navy front door with a splintered frame and a smashed lock after a break-in',
    width: 1000,
    height: 1507,
    // Top-aligned so the tall photos keep their BEFORE / AFTER tags when cropped square on phones.
    focalPoint: { x: 50, y: 0 },
  },
  'breakin-after': {
    id: 'breakin-after',
    src: '/images/breakin-after.jpg',
    alt: 'After: the same door with the frame repaired, freshly painted, and a new brass lock fitted',
    width: 1000,
    height: 1507,
    // Top-aligned so the tall photos keep their BEFORE / AFTER tags when cropped square on phones.
    focalPoint: { x: 50, y: 0 },
  },
};

export function getImage(id: ImageId): ImageAsset {
  return IMAGES[id];
}
